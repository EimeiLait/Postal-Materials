﻿from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import CMYKColor as CMYKcolor
from barcode.writer import ImageWriter
from PIL import Image
from reportlab.graphics.barcode import code128
import barcode
import io





pdfmetrics.registerFont(TTFont("optimaHeavy", "./fonts/OptimaNovaLTProHeavy.ttf"))
pdfmetrics.registerFont(TTFont("optimaBlack", "./fonts/OptimaNovaLTProBlack.ttf"))
pdfmetrics.registerFont(TTFont("optimaMid", "./fonts/OptimaNovaLTProMedium.ttf"))
pdfmetrics.registerFont(TTFont("fangSong", "./fonts/fangSong2312.ttf"))
pdfmetrics.registerFont(TTFont("oCR_B", "./fonts/OCRB.ttf"))
pdfmetrics.registerFont(TTFont("oCR_A", "./fonts/OCRA.ttf"))




natureCheck = False
vrifcation = 0
serialNum = 0
red = CMYKcolor(0, 1, 1, 0)
black = CMYKcolor(0, 0, 0, 1)
green = CMYKcolor(1, 0, 1, 0)
white = CMYKcolor(0, 0, 0, 0)

serialSepChar1 = 0
serialSepChar2 = 0
serialSepChar3 = 0
serialSepChar4 = 0
serialSepChar5 = 0
serialSepChar6 = 0
serialSepChar7 = 0
serialSepChar8 = 0
numFinStr = ' '
numFinInt = 0
lit = 'R'
bitFill = 0
code128Bin = ''
text = ''
space = 0


def menuNature():
    print('X = 信函')
#    print('S = 印刷品')
    print('')
    print('')
    return None

def numSeparating():
    global serialNum
    serialNum = input('Enter the first serial number, No spaces, 8 digits:')
    for i, char in enumerate(serialNum) :
        globals()[f'serialSepChar{i+1}'] = int(char)

def calcVrifcation(digits):
    global vrifcation
    
    weights = [8, 6, 4, 2, 3, 5, 9, 7]
    b = sum(d * w for d, w in zip(digits, weights))
    b = 11 - (b % 11)

    if 1 <= b <= 9:
        vrifcation = b
        return b
    
    elif b == 10:
        vrifcation = 0
        return 0
    
    elif b == 11:
        vrifcation = 5
        return 5


def serialCumVrifcation(serialNum):
    serialStr = str(serialNum)
    digits = [int(ch) for ch in serialStr]
    v = calcVrifcation(digits)

    if v is not None:
        numFStr = serialStr + str(v)
        numFInt = int(numFStr)
        return numFStr, numFInt


def formattedFin(serialNum, vrifcation):
    serialStr = str(serialNum)
    part1 = serialStr[:4]
    part2 = serialStr[4:]
    result = f"{nature}{litSec} {part1} {part2} {vrifcation} {province}"
    return result


def code128bin(text):
    rv = io.BytesIO()
    code128 = barcode.get('code128', text, writer=ImageWriter())
    code128.write(rv, options={
    'module_height': 10,
    'module_width': 1,
    'quiet_zone': 0,
    'write_text': False,
    })

    rv.seek(0)
    img = Image.open(rv).convert('1')

    pixels = img.load()
    width, height = img.size
    binary = ''
    for x in range(width):
        binary += '0' if pixels[x, 0] == 0 else '1'

    return binary


def digiSep(serialNum):
    global serialSepChar1, serialSepChar2, serialSepChar3, serialSepChar4
    global serialSepChar5, serialSepChar6, serialSepChar7, serialSepChar8
    serialSepChar1, serialSepChar2, serialSepChar3, serialSepChar4, serialSepChar5, serialSepChar6, serialSepChar7, serialSepChar8 = [int(d) for d in str(serialNum)]
    return None



print('Postal barcode generator')
print('Developed by Ei.Laitus')
print('Jul. 2025')
print('visit github.com/EimeiLait/postal-materials or mail to B.P. 15-10 PEKIN R.P. de CHINE')


while not natureCheck:
    red = CMYKcolor(0, 1, 1, 0)
    menuNature()
    nature = str(input('Enter the code to Select a nature:'))
    if nature in ['X','S']:
        natureCheck = True

        mapping = {
            "X": "信",
            "S": "刷",
            "3": "c",
            "4": "d"
        }

        natureFull = mapping.get(nature)
        
    else:
        natureCheck = False
        print('Invalid input. Please try again.')

# pdf
c = canvas.Canvas("output.pdf", pagesize=(842, 595)) # unit: pt

##################################################


serialNum = input('Enter the first 8-digit serial number')

while True:  
    litSec = input('Enter the second letter (A–Z, except I, J, O, and W)')
    if litSec not in ('I', 'J', 'O', 'W'):
        break
    else:
        print('Retry')

province = input('Enter the 2-digit province code.')

while True:
    serialNum = str(serialNum)
    if serialNum.isdigit() and len(serialNum) == 8:
        serialNum = int(serialNum)
        print('Select the font for serial numbers.')
        numFont = input('OCR A(a or A) or OCR B(b or B):')
        if numFont == 'A' or numFont == 'a':
            numFont = 'oCR_A'
            break
        elif numFont == 'B' or numFont == 'b':
            numFont = 'oCR_B'
            break
    else:
        print = ('Retry')

#####

c.setFillColor(green)

x = 39
y = 497

for i in range(6):
    for j in range(9):
            
        c.rect(x, y, 128, 12, fill=1, stroke=0)
        y -= 60
        
    x += 120
    y = 497

#########

text = c.beginText()
text.setFillColor(black)
text.setFont(numFont, 9)
text.setCharSpace(-0.2)
text.setTextOrigin(48, 570)
text.textOut("by Ei. Laitus, https://github.com/EimeiLait/postal-materials")
c.drawText(text)
text.setCharSpace(-0.3)
text.setTextOrigin(48, 560)
text.textOut("CC BY-NC-SA 4.0 https://creativecommons.org/licenses/by-nc-sa/4.0/")
c.drawText(text)


text = c.beginText()
text.setFillColor(white)
text.setFont(numFont, 9)
text.setCharSpace(-0.1)

x = 48
y = 499

for i in range(6):
    for j in range(9):
    
        text.setTextOrigin(x, y)
        text.textOut("SIMOKITA(L)100000")
        c.drawText(text)

        y -= 60

    y = 499
    x = x + 120


######

c.setFont(numFont, 9)
c.setFillColor(black)
c.setFont("fangSong", 8.5)

x = 44
y = 513

for i in range(6):
    for j in range(9):
    
        numFStr, numFInt = serialCumVrifcation(serialNum)
        formatted = formattedFin(serialNum, vrifcation)
        c.drawString(x, y, f"{natureFull}")
        y -= 60

    y = 513
    x = x + 120
########

c.setFillColor(black)
text = c.beginText()
text.setFont(numFont, 9)

x = 54
y = 512

for i in range(6):
    for j in range(9):
        
        numFStr, numFInt = serialCumVrifcation(serialNum)
        formatted = formattedFin(serialNum, vrifcation)

        digiSep(serialNum)
        text.setTextOrigin(x, y)
        text.setCharSpace(-0.5)
        text.textOut(f"{nature}{litSec}")
        c.drawText(text)
        x += 17
        
        text.setTextOrigin(x, y)
        text.setCharSpace(-0.5)
        text.textOut(f"{serialSepChar1}{serialSepChar2}{serialSepChar3}{serialSepChar4}")
        c.drawText(text)
        x += 30

        text.setTextOrigin(x, y)
        text.textOut(f"{serialSepChar5}{serialSepChar6}{serialSepChar7}{serialSepChar8}")
        c.drawText(text)
        x += 30

        text.setTextOrigin(x, y)
        text.textOut(f"{vrifcation}")
        c.drawText(text)
        x += 13
        
        text.setTextOrigin(x, y)
        text.textOut(f"{province}")
        c.drawText(text)

        x -= 90
        y -= 60
        serialNum += 1

    y = 512
    x += 120

###############barcode

codeX = 30
codeY = 523
serialNum -= 54

for i in range(6):
    for j in range(9):
            
        numFStr, numFInt = serialCumVrifcation(serialNum)
        formatted = formattedFin(serialNum, vrifcation)
        formattedCleaned = formatted.replace(" ", "")
        barcodeObj = code128.Code128(formattedCleaned, barHeight=30, barWidth=0.82)
        barcodeObj.drawOn(c, codeX, codeY)
                
        serialNum += 1
        codeY -= 60
        
    codeX += 120
    codeY = 523


c.save()

input('Operation completed. Press [Enter] to exit')

