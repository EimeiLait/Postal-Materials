﻿from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import CMYKColor as CMYKcolor
from barcode.writer import ImageWriter
from PIL import Image
from reportlab.graphics.barcode import code128
from reportlab.graphics.barcode import code39
import barcode
import io





pdfmetrics.registerFont(TTFont("optimaHeavy", "./fonts/OptimaNovaLTProHeavy.ttf"))
pdfmetrics.registerFont(TTFont("optimaBlack", "./fonts/OptimaNovaLTProBlack.ttf"))
pdfmetrics.registerFont(TTFont("optimaMid", "./fonts/OptimaNovaLTProMedium.ttf"))
pdfmetrics.registerFont(TTFont("fangSong", "./fonts/fangSong2312.ttf"))
pdfmetrics.registerFont(TTFont("oCR_B", "./fonts/OCRB.ttf"))
pdfmetrics.registerFont(TTFont("oCR_A", "./fonts/OCRA.ttf"))




natureCheck = False
vrifcation = 0
serialNum = 0
red = CMYKcolor(0, 1, 1, 0)
black = CMYKcolor(0, 0, 0, 1)
green = CMYKcolor(1, 0, 1, 0)
white = CMYKcolor(0, 0, 0, 0)
cyan = CMYKcolor(1,0,0,0)

serialSepChar1 = 0
serialSepChar2 = 0
serialSepChar3 = 0
serialSepChar4 = 0
serialSepChar5 = 0
serialSepChar6 = 0
serialSepChar7 = 0
serialSepChar8 = 0
serialSepChar9 = 0
serialSepChar10 = 0
serialSepChar11 = 0
serialSepChar12 = 0
serialSepChar13 = 0

numFinStr = ' '
numFinInt = 0
lit = 'R'
bitFill = 0
code128Bin = ''
text = ''
space = 0
natureCode = ''
codeForR = ''
altRFormat = ''


def menuNature():
    print('X = 给据信函')
#    print('S = 印刷品')
    print('N = 平常信函和平常印刷品')
    print('R = 国际挂号函件')
    print('V = 国际保价函件')
    print('CV = 国际保价包裹')
    return None

def numSeparating():
    global serialNum
    if menuNature == ('X', 'R', 'V', 'CV'):
        serialNum = input('Enter the first serial number, No spaces, 8 digits:')
    elif menuNature == 'N':
        serialNum = input('Enter the first serial number, No spaces, 13 digits:')
    for i, char in enumerate(serialNum) :
        globals()[f'serialSepChar{i+1}'] = int(char)

def calcVrifcation(digits):
    global vrifcation
    
    weights = [8, 6, 4, 2, 3, 5, 9, 7]
    b = sum(d * w for d, w in zip(digits, weights))
    b = 11 - (b % 11)

    if 1 <= b <= 9:
        vrifcation = b
        return b
    
    elif b == 10:
        vrifcation = 0
        return 0
    
    elif b == 11:
        vrifcation = 5
        return 5


def serialCumVrifcation(serialNum):
    serialStr = str(serialNum)
    digits = [int(ch) for ch in serialStr]
    v = calcVrifcation(digits)

    if v is not None:
        numFStr = serialStr + str(v)
        numFInt = int(numFStr)
        return numFStr, numFInt


def formattedFin(serialNum, vrifcation):
    serialStr = str(serialNum)
    part1 = serialStr[:4]
    part2 = serialStr[4:]
    if nature == 'CV':
        result = f"C{litSec} {part1} {part2} {vrifcation} {province}"
    else:
        result = f"{nature}{litSec} {part1} {part2} {vrifcation} {province}"
    return result


def code128bin(text):
    rv = io.BytesIO()
    code128 = barcode.get('code128', text, writer=ImageWriter())
    code128.write(rv, options={
    'module_height': 10,
    'module_width': 1,
    'quiet_zone': 0,
    'write_text': False,
    })

    rv.seek(0)
    img = Image.open(rv).convert('1')

    pixels = img.load()
    width, height = img.size
    binary = ''
    for x in range(width):
        binary += '0' if pixels[x, 0] == 0 else '1'

    return binary


def digiSep(serialNum):
    global serialSepChar1, serialSepChar2, serialSepChar3, serialSepChar4
    global serialSepChar5, serialSepChar6, serialSepChar7, serialSepChar8
    global serialSepChar9, serialSepChar10, serialSepChar11, serialSepChar12
    global serialSepChar13
    if nature == 'N':
        serialSepChar1, serialSepChar2, serialSepChar3, serialSepChar4, serialSepChar5, serialSepChar6, serialSepChar7, serialSepChar8, serialSepChar9, serialSepChar10, serialSepChar11, serialSepChar12, serialSepChar13 = [int(d) for d in str(serialNum)]
    elif nature in ('R', 'X', 'V', 'CV'):
        serialSepChar1, serialSepChar2, serialSepChar3, serialSepChar4, serialSepChar5, serialSepChar6, serialSepChar7, serialSepChar8 = [int(d) for d in str(serialNum)]
    return None



print('Postal barcode generator - 1.0')
print('Developed by Ei.Laitus')
print('Oct. 2025')
print('visit github.com/EimeiLait/postal-materials or mail to B.P. 15-10 PEKIN R.P. de CHINE')


while not natureCheck:
    red = CMYKcolor(0, 1, 1, 0)
    menuNature()
    nature = str(input('Enter the code to Select a nature:'))
    if nature in ['X','S','N','R','V', 'CV']:
        natureCheck = True

        mapping = {
            'X': "信",
            'S': "刷",
            'N': "平",
            'R': "R",
            'V': "V",
            'CV': "C"
        }

        natureFull = mapping.get(nature)

        mapping = {
            'X': "信",
            'S': "刷",
            'N': "平",
            'R': "R",
            'V': "V"
        }

        natureCode = mapping.get(nature)
        
    else:
        natureCheck = False
        print('Invalid input. Please try again.')

# pdf
c = canvas.Canvas("edge.pdf", pagesize=(842, 595)) # unit: pt

##################################################


if nature in ('X', 'R', 'V', 'CV'):
        serialNum = input('Enter the first serial number, No spaces, 8 digits:')
elif nature == 'N':
        serialNum = input('Enter the first serial number, No spaces, 13 digits:')

while nature in ('X', 'R', 'V', 'CV'):
    if nature in ('X', 'R', 'V'):
        litSec = input('Enter the second letter (A–Z, except I, J, O, and W)')
        if litSec not in ('I', 'J', 'O', 'W'):
            break
        else:
            print('Retry')
    elif nature == 'CV':
        litSec = 'V'
        break
            
    

if nature == 'X':
    province = input('Enter the 2-digit province code.')
elif nature in ('R', 'V', 'CV'):
    province = input('Enter the 2-digit country or region code.')

while True:
    serialNum = str(serialNum)
    if nature in ('X', 'R', 'V', 'CV'):
        if serialNum.isdigit() and len(serialNum) == 8:
            serialNum = int(serialNum)
    elif nature == 'N':
        if serialNum.isdigit() and len(serialNum) == 13:
            serialNum = int(serialNum)
            
    print('Select the font for serial numbers.')
    numFont = input('OCR A(a or A) or OCR B(b or B):')
    if numFont == 'A' or numFont == 'a':
        numFont = 'oCR_A'
        break
    elif numFont == 'B' or numFont =='b':
         numFont = 'oCR_B'
         break
    else:
        print = ('Retry')

if nature in ('R', 'V', 'CV'):
    codeForR = input('Input Code 128 (128) or Code 39 (39):')
    altRFormat = input('Use the alternative spacing NN/NNN/NNN/N instead of NNN/NNN/NNN? (Y/N)')

if nature in ('X', 'N'):
    
    if nature == 'X':
        c.setFillColor(green)
    elif nature == 'N':
        c.setFillColor(cyan)

    x = 39
    y = 497

    for i in range(6):
        for j in range(9):
                
            c.rect(x, y, 128, 12, fill=1, stroke=0)
            y -= 60
            
        x += 120
        y = 497

elif nature in ('R', 'V', 'CV'):
    
    c.setFont("optimaBlack", 34)

    x = 156
    y = 527

    for i in range(3):
        for j in range(7):
            if nature == 'R':
                c.setFillColor(red)
                c.drawString(x, y, 'R')
                y -= 5
                c.rect(x, y, 196, 1.5, fill=1, stroke=0)
                y -= 3
                c.rect(x, y, 196, 0.5, fill=1, stroke=0)
                y -= 57.5
            elif nature == 'V':
                c.setFillColor(black)
                c.drawString(x, y, 'V')
                y -= 5
                c.rect(x, y, 196, 1.5, fill=1, stroke=0)
                y -= 3
                c.rect(x, y, 196, 0.5, fill=1, stroke=0)
                y -= 57.5
            
        x += 210
        y = 527

#########

text = c.beginText()
text.setFillColor(white)
text.setFont(numFont, 9)
text.setCharSpace(-0.1)

x = 48
y = 499

for i in range(6):
    for j in range(9):
        
        if nature == 'X':
            text.setTextOrigin(x, y)
            text.textOut("SIMOKITA(L)100000")
            c.drawText(text)
        elif nature == 'N':
            text.setTextOrigin(x, y)
            text.textOut("PX  155-0031(L)")
            c.drawText(text)
            
        y -= 60

    y = 499
    x = x + 120

c.save()
######

c = canvas.Canvas("code.pdf", pagesize=(842, 595)) # unit: pt


text = c.beginText()
text.setFillColor(black)
text.setFont(numFont, 9)
text.setCharSpace(-0.2)
if nature not in ('R', 'V', 'CV'):
    text.setTextOrigin(48, 570)
else:
    text.setTextOrigin(48, 60)
text.textOut("by Ei. Laitus, https://github.com/EimeiLait/postal-materials")
c.drawText(text)
text.setCharSpace(-0.3)
if nature not in ('R', 'V'):
    text.setTextOrigin(48, 560)
else:
    text.setTextOrigin(48, 50)
text.textOut("CC BY-NC-SA 4.0 https://creativecommons.org/licenses/by-nc-sa/4.0/")
c.drawText(text)


c.setFont(numFont, 9)
c.setFillColor(black)
c.setFont("fangSong", 8.5)

x = 44
y = 513

if nature == 'X':
    for i in range(6):
        for j in range(9):
        
            numFStr, numFInt = serialCumVrifcation(serialNum)
            formatted = formattedFin(serialNum, vrifcation)
            c.drawString(x, y, f"{natureFull}")
            y -= 60

        y = 513
        x = x + 120
########

c.setFillColor(black)
text = c.beginText()
text.setFont(numFont, 9)




if nature == 'X':
    
    x = 54
    y = 512
    
    for i in range(6):
        for j in range(9):

            digiSep(serialNum)

            numFStr, numFInt = serialCumVrifcation(serialNum)
            formatted = formattedFin(serialNum, vrifcation)

            digiSep(serialNum)
            text.setTextOrigin(x, y)
            text.setCharSpace(-0.5)
            text.textOut(f"{nature}{litSec}")
            c.drawText(text)
            x += 17
                
            text.setTextOrigin(x, y)
            text.setCharSpace(-0.5)
            text.textOut(f"{serialSepChar1}{serialSepChar2}{serialSepChar3}{serialSepChar4}")
            c.drawText(text)
            x += 30

            text.setTextOrigin(x, y)
            text.textOut(f"{serialSepChar5}{serialSepChar6}{serialSepChar7}{serialSepChar8}")
            c.drawText(text)
            x += 30

            text.setTextOrigin(x, y)
            text.textOut(f"{vrifcation}")
            c.drawText(text)
            x += 13
                    
            text.setTextOrigin(x, y)
            text.textOut(f"{province}")
            c.drawText(text)

            x -= 90
            y -= 60
            serialNum += 1

        y = 512
        x += 120

elif nature in ('R', 'V', 'CV'):

    x = 192
    y = 530
    
    for i in range(3):
        for j in range(7):

            digiSep(serialNum)

            numFStr, numFInt = serialCumVrifcation(serialNum)
            formatted = formattedFin(serialNum, vrifcation)

            if altRFormat == 'Y':

                text.setFont(numFont, 12)
                digiSep(serialNum)
                text.setTextOrigin(x, y)
                text.setCharSpace(-0.8)
                if nature == 'CV':
                    text.textOut(f"C{litSec}")
                else:
                    text.textOut(f"{nature}{litSec}")
                c.drawText(text)
                x += 20
                
                text.setFont(numFont, 14)
                text.setTextOrigin(x, y)
                text.textOut(f"{serialSepChar1}{serialSepChar2}")
                c.drawText(text)
                x += 25

                text.setTextOrigin(x, y)
                text.textOut(f"{serialSepChar3}{serialSepChar4}{serialSepChar5}")
                c.drawText(text)
                x += 34

                text.setTextOrigin(x, y)
                text.textOut(f"{serialSepChar6}{serialSepChar7}{serialSepChar8}")
                c.drawText(text)
                x += 38

                text.setFont(numFont, 12)
                text.setTextOrigin(x, y)
                text.textOut(f"{vrifcation}")
                c.drawText(text)
                x += 15
                        
                text.setTextOrigin(x, y)
                text.textOut(f"{province}")
                c.drawText(text)

            elif altRFormat == 'N':

                text.setFont(numFont, 12)
                digiSep(serialNum)
                text.setTextOrigin(x, y)
                text.setCharSpace(-0.8)
                if nature == 'CV':
                    text.textOut(f"C{litSec}")
                else:
                    text.textOut(f"{nature}{litSec}")
                c.drawText(text)
                x += 24
                
                text.setFont(numFont, 14)
                text.setTextOrigin(x, y)
                text.textOut(f"{serialSepChar1}{serialSepChar2}{serialSepChar3}")
                c.drawText(text)
                x += 36

                text.setTextOrigin(x, y)
                text.textOut(f"{serialSepChar4}{serialSepChar5}{serialSepChar6}")
                c.drawText(text)
                x += 36

                text.setTextOrigin(x, y)
                text.textOut(f"{serialSepChar7}{serialSepChar8}{vrifcation}")
                c.drawText(text)
                x += 36

                text.setFont(numFont, 12)
                text.setTextOrigin(x, y)
                text.textOut(f"{province}")
                c.drawText(text)

            if altRFormat == 'Y':
                x -= 130
            elif altRFormat == 'N':
                x -= 132
                
            y -= 66
            serialNum += 1

        y = 530
        x += 210

elif nature == 'N':

    x = 50
    y = 512
    
    for i in range(6):
        for j in range(9):

            digiSep(serialNum)

            text.setTextOrigin(x, y)
            text.setCharSpace(-0.5)
            text.textOut(f"{serialSepChar1}{serialSepChar2}{serialSepChar3}{serialSepChar4}")
            c.drawText(text)
            x += 30

            text.setTextOrigin(x, y)
            text.textOut(f"{serialSepChar5}{serialSepChar6}{serialSepChar7}{serialSepChar8}")
            c.drawText(text)
            x += 30

            text.setTextOrigin(x, y)
            text.textOut(f"{serialSepChar9}{serialSepChar10}{serialSepChar11}{serialSepChar12}")
            c.drawText(text)
            x += 30

            text.setTextOrigin(x, y)
            text.textOut(f"{serialSepChar13}")
            c.drawText(text)
            
            x -= 90
            y -= 60
            serialNum += 1

        y = 512
        x += 120

###############barcode



if nature == 'X':
    
    serialNum -= 54
    
    codeX = 30
    codeY = 523
             
    for i in range(6):
        for j in range(9):

            numFStr, numFInt = serialCumVrifcation(serialNum)
            formatted = formattedFin(serialNum, vrifcation)
            formattedCleaned = formatted.replace(" ", "")
            barcodeObj = code128.Code128(formattedCleaned, barHeight=30, barWidth=0.82)
            barcodeObj.drawOn(c, codeX, codeY)
                        
            serialNum += 1
            codeY -= 60
                
        codeX += 120
        codeY = 523

elif nature == 'N':

    serialNum -= 54

    codeX = 30
    codeY = 523
    
    for i in range(6):
        for j in range(9):
             
            barcodeObj = code128.Code128(serialNum, barHeight=30, barWidth=0.82)
            barcodeObj.drawOn(c, codeX, codeY)
                        
            serialNum += 1
            codeY -= 60
                
        codeX += 120
        codeY = 523

elif nature in ('R', 'V', 'CV'):

    serialNum -= 21

    codeX = 150
    codeY = 490
             
    for i in range(3):
        for j in range(7):
            if codeForR == '128':

                numFStr, numFInt = serialCumVrifcation(serialNum)
                formatted = formattedFin(serialNum, vrifcation)
                formattedCleaned = formatted.replace(" ", "")
                barcodeObj = code128.Code128(formattedCleaned, barHeight=27, barWidth=1.2)
                barcodeObj.drawOn(c, codeX, codeY)
                
            elif codeForR == '39':
                
                numFStr, numFInt = serialCumVrifcation(serialNum)
                formatted = formattedFin(serialNum, vrifcation)
                formattedCleaned = formatted.replace(" ", "")
                barcodeObj = code39.Standard39(formattedCleaned, barHeight=27, barWidth=0.85)
                barcodeObj.drawOn(c, codeX, codeY)
                        
            serialNum += 1
            codeY -= 66
                
        codeX += 210
        codeY = 490
        
if nature == 'V':
    
    c.setFont("optimaBlack", 34)

    x = 156
    y = 527

    for i in range(3):
        for j in range(7):

            c.setFillColor(black)
            c.drawString(x, y, 'V')
            y -= 5
            c.rect(x, y, 196, 1.5, fill=1, stroke=0)
            y -= 3
            c.rect(x, y, 196, 0.5, fill=1, stroke=0)
            y -= 57.5
            
        x += 210
        y = 527


c.save()

input('Operation completed. Press [Enter] to exit')

